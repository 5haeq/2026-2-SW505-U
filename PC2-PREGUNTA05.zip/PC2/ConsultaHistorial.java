public class ConsultaHistorial {
    private String historial; 
    
    public void consultar(){
        System.out.println(
            historial + " se ha consultado correctamente"
        ); 
    };    
}