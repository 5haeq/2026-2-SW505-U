public class ServicioFirmaDigital {

    private String firma; 

    public void firmar(String firma){
        System.out.println(
            "Firmado correctamente con " + firma
        );

    }
}