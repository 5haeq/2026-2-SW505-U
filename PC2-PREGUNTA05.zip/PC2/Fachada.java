public class Fachada{
    private final ConsultaHistorial cHistorial; 
    private final GeneradorCuenta gCuenta; 
    private final NotificadorCliente nCliente; 
    private final ServicioFirmaDigital sfDigital; 
    private final ValidadorHistorial vHistorial; 

    public Fachada(){
        this.cHistorial = new ConsultaHistorial();
        this.nCliente = new Notificador(); 
        this.sfDigital = new ServicioFirmaDigital();
        this.vHistorial = new ValidadorHistorial(); 
    }

    public class aperturarCuenta{
        String his;  
        String firma; 
        String DNI; 
    }
}