import FabricadorNotificador; 

public abstract class Notificador{

    private String msg;

    abstract notificacion crearNotificacion(); 

    public void notificar(String msg){
        notificacion noti = crearNotificacion(); 
        noti.enviar(mensaje); 
    }

    public class NotificadorEmail extends Notificador {
    @Override
    Notificacion crearNotificacion() {
        return new NotificacionEmail();
        }
    }
    public class NotificadorSMS extends Notificador {
    @Override
    Notificacion crearNotificacion() {
            return new NotificacionSMS();
        }
    }
    

}