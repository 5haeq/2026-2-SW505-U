public class ValidadorHistorial {

    private String DNI; 

    public void validar(String codigo) {
       System.out.println(
        "Sistema" + DNI + "verificado con RENIEC: " 
       ); 
    }
}