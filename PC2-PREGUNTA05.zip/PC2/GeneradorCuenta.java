public class GeneradorCuenta {
    private String cuenta; 

    public void generar(){
        System.out.println(
            cuenta + " se ha generado correctamente"
        ); 
    };    
}